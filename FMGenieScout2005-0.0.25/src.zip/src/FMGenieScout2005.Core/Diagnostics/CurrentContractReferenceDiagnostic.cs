using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Procura a estrutura dinâmica que vincula uma pessoa ao clube atual.
/// Compara jogadores do Flamengo e do Corinthians, sem assumir um offset fixo.
/// Somente leitura; nenhum byte do save é modificado.
/// </summary>
public sealed class CurrentContractReferenceDiagnostic
{
    private const uint FlamengoDatabaseId = 322;
    private const uint CorinthiansDatabaseId = 319;
    private const int SearchRadius = 4096;
    private const int ContextBefore = 48;
    private const int ContextAfter = 80;

    private static readonly CurrentContractSample[] Samples =
    [
        new("Andrezinho", 302728, FlamengoDatabaseId, "CR Flamengo"),
        new("André Bahia", 311169, FlamengoDatabaseId, "CR Flamengo"),
        new("Bruno Santos", 8832815, FlamengoDatabaseId, "CR Flamengo"),
        new("Dimba", 303048, FlamengoDatabaseId, "CR Flamengo"),
        new("Douglas Silva", 3300410, FlamengoDatabaseId, "CR Flamengo"),
        new("Fabiano Eller", 3300219, FlamengoDatabaseId, "CR Flamengo"),
        new("Júlio César Moraes", 8825041, FlamengoDatabaseId, "CR Flamengo"),
        new("Júnior Baiano", 6900111, FlamengoDatabaseId, "CR Flamengo"),
        new("Reginaldo Araújo", 3300780, FlamengoDatabaseId, "CR Flamengo"),

        new("Édson Araújo", 308345, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Fábio Baiano", 3300471, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Fábio Costa", 6900151, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Luciano Ratinho", 6900008, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Marcelo Magalhães", 302580, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Bruno Octávio", 8832887, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Alessandro", 3902245, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Rosinei", 316596, CorinthiansDatabaseId, "SC Corinthians Paulista"),
        new("Dinélson", 320774, CorinthiansDatabaseId, "SC Corinthians Paulista")
    ];

    private readonly Fm2005PersonIdentityParser _personParser = new();
    private readonly Fm2005ClubParser _clubParser = new();

    public async Task<CurrentContractReferenceReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Resolvendo identidades e índices dos clubes atuais...");
        Fm2005PersonIdentityParseResult people = _personParser.Parse(data, source, sha, progress, cancellationToken);
        Fm2005ClubParseResult clubs = _clubParser.Parse(data, cancellationToken);
        Club flamengo = clubs.FindByDatabaseId(FlamengoDatabaseId)
            ?? throw new InvalidDataException("O Flamengo (ClubDatabaseId 322) não foi localizado.");
        Club corinthians = clubs.FindByDatabaseId(CorinthiansDatabaseId)
            ?? throw new InvalidDataException("O Corinthians (ClubDatabaseId 319) não foi localizado.");

        var occurrences = new List<CurrentContractOccurrence>();
        var hits = new List<CurrentClubReferenceHit>();
        var missing = new List<string>();

        foreach (CurrentContractSample sample in Samples)
        {
            cancellationToken.ThrowIfCancellationRequested();
            PersonIdentity? person = people.FindByDatabaseId(sample.PersonDatabaseId);
            if (person is null)
            {
                missing.Add($"{sample.DisplayName};{sample.PersonDatabaseId};IDENTIDADE_NAO_ENCONTRADA");
                continue;
            }

            uint clubSaveIndex = sample.ExpectedClubDatabaseId == FlamengoDatabaseId
                ? flamengo.SaveIndex
                : corinthians.SaveIndex;
            long identityDatabaseIdOffset = person.NameOffset + (long)person.NameLength * 2L + 12L;

            AddReferenceKind(data, sample, person, "PERSON_DATABASE_ID", person.DatabaseId,
                clubSaveIndex, identityDatabaseIdOffset, occurrences, hits, cancellationToken);
            AddReferenceKind(data, sample, person, "INTERNAL_PERSON_ID", person.SequenceIndex,
                clubSaveIndex, identityDatabaseIdOffset, occurrences, hits, cancellationToken);
        }

        progress?.Report("Agrupando offsets compartilhados entre Flamengo e Corinthians...");
        CurrentClubOffsetSummary[] summaries = hits
            .Where(x => !x.IsIdentityOccurrence && !x.IsKnownMinus17)
            .GroupBy(x => new { x.ReferenceKind, x.DataType, x.RelativeOffset })
            .Select(g =>
            {
                string[] fla = g.Where(x => x.ExpectedClubDatabaseId == FlamengoDatabaseId)
                    .Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
                string[] cor = g.Where(x => x.ExpectedClubDatabaseId == CorinthiansDatabaseId)
                    .Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
                int total = fla.Length + cor.Length;
                string assessment = fla.Length >= 5 && cor.Length >= 5 ? "CURRENT_CLUB_CANDIDATE_STRONG"
                    : fla.Length >= 3 && cor.Length >= 3 ? "CURRENT_CLUB_CANDIDATE_MEDIUM"
                    : total >= 4 ? "CURRENT_CLUB_CANDIDATE_WEAK"
                    : "AUXILIARY_REFERENCE";
                return new CurrentClubOffsetSummary(
                    g.Key.ReferenceKind, g.Key.DataType, g.Key.RelativeOffset,
                    fla.Length, cor.Length, total, g.Count(),
                    string.Join(" | ", fla), string.Join(" | ", cor), assessment);
            })
            .OrderByDescending(x => Math.Min(x.FlamengoPlayers, x.CorinthiansPlayers))
            .ThenByDescending(x => x.DistinctPlayers)
            .ThenByDescending(x => x.TotalHits)
            .ThenBy(x => Math.Abs(x.RelativeOffset))
            .ToArray();

        var report = new CurrentContractReferenceReport(
            source, data.LongLength, sha, flamengo.SaveIndex, corinthians.SaveIndex,
            occurrences.OrderBy(x => x.DisplayName).ThenBy(x => x.ReferenceKind).ThenBy(x => x.ReferenceOffset).ToArray(),
            hits.OrderBy(x => x.DisplayName).ThenBy(x => x.ReferenceKind).ThenBy(x => x.ReferenceOffset).ThenBy(x => x.ClubValueOffset).ToArray(),
            summaries, missing, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios do vínculo dinâmico...");
        await File.WriteAllTextAsync(Path.Combine(output, "current-contract-reference-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "current-contract-occurrences.csv"), FormatOccurrencesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "current-club-reference-hits.csv"), FormatHitsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "current-club-offset-summaries.csv"), FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "current-club-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllLinesAsync(Path.Combine(output, "players-without-current-club-pattern.txt"), report.MissingPeople, new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Diagnóstico do clube atual concluído.");
        return report;
    }

    private static void AddReferenceKind(
        byte[] data,
        CurrentContractSample sample,
        PersonIdentity person,
        string referenceKind,
        uint referenceValue,
        uint expectedClubSaveIndex,
        long identityDatabaseIdOffset,
        List<CurrentContractOccurrence> occurrences,
        List<CurrentClubReferenceHit> hits,
        CancellationToken cancellationToken)
    {
        foreach (int referenceOffset in FindUInt32(data, referenceValue, cancellationToken))
        {
            bool identityOccurrence = Math.Abs((long)referenceOffset - identityDatabaseIdOffset) <= 64L;
            occurrences.Add(new CurrentContractOccurrence(
                sample.DisplayName, sample.PersonDatabaseId, person.SequenceIndex,
                sample.ExpectedClubDatabaseId, expectedClubSaveIndex, referenceKind,
                referenceOffset, identityOccurrence,
                HexContext(data, referenceOffset, ContextBefore, ContextAfter)));

            AddCurrentClubHits(data, sample, person, referenceKind, referenceOffset,
                expectedClubSaveIndex, identityOccurrence, hits);
        }
    }

    private static void AddCurrentClubHits(
        byte[] data,
        CurrentContractSample sample,
        PersonIdentity person,
        string referenceKind,
        int referenceOffset,
        uint expectedClubSaveIndex,
        bool identityOccurrence,
        List<CurrentClubReferenceHit> output)
    {
        int start = Math.Max(0, referenceOffset - SearchRadius);
        int end = Math.Min(data.Length, referenceOffset + 4 + SearchRadius);

        for (int offset = start; offset <= end - 2; offset++)
        {
            if (expectedClubSaveIndex <= ushort.MaxValue &&
                BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2)) == expectedClubSaveIndex)
            {
                int relative = offset - referenceOffset;
                output.Add(CreateHit(sample, person, referenceKind, referenceOffset, expectedClubSaveIndex,
                    "UINT16", offset, relative, identityOccurrence, data));
            }

            if (offset <= end - 4 && BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4)) == expectedClubSaveIndex)
            {
                int relative = offset - referenceOffset;
                output.Add(CreateHit(sample, person, referenceKind, referenceOffset, expectedClubSaveIndex,
                    "UINT32", offset, relative, identityOccurrence, data));
            }
        }
    }

    private static CurrentClubReferenceHit CreateHit(
        CurrentContractSample sample,
        PersonIdentity person,
        string referenceKind,
        int referenceOffset,
        uint expectedClubSaveIndex,
        string dataType,
        int clubOffset,
        int relative,
        bool identityOccurrence,
        byte[] data)
    {
        return new CurrentClubReferenceHit(
            sample.DisplayName, sample.PersonDatabaseId, person.SequenceIndex,
            sample.ExpectedClubDatabaseId, sample.ExpectedClubName, expectedClubSaveIndex,
            referenceKind, referenceOffset, dataType, clubOffset, relative,
            identityOccurrence, relative == -17,
            HexContext(data, clubOffset, 16, 20));
    }

    private static List<int> FindUInt32(byte[] data, uint value, CancellationToken cancellationToken)
    {
        byte b0 = (byte)value;
        byte b1 = (byte)(value >> 8);
        byte b2 = (byte)(value >> 16);
        byte b3 = (byte)(value >> 24);
        var result = new List<int>();
        for (int i = 0; i <= data.Length - 4; i++)
        {
            if ((i & 0xFFFF) == 0) cancellationToken.ThrowIfCancellationRequested();
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3)
                result.Add(i);
        }
        return result;
    }

    private static string HexContext(byte[] data, int center, int before, int after)
    {
        int start = Math.Max(0, center - before);
        int length = Math.Min(data.Length - start, before + 4 + after);
        return Convert.ToHexString(data.AsSpan(start, length));
    }

    public static string FormatReport(CurrentContractReferenceReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — CurrentContractReferenceDiagnostic 0.0.25");
        sb.AppendLine(new string('=', 98));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Flamengo SaveIndex: {report.FlamengoSaveIndex}");
        sb.AppendLine($"Corinthians SaveIndex: {report.CorinthiansSaveIndex}");
        sb.AppendLine($"Ocorrências de pessoa: {report.Occurrences.Count:N0}");
        sb.AppendLine($"Hits do clube esperado em ±{SearchRadius:N0} bytes: {report.ClubHits.Count:N0}");
        sb.AppendLine($"Pessoas não resolvidas: {report.MissingPeople.Count:N0}");
        sb.AppendLine();

        sb.AppendLine("Melhores offsets compartilhados entre os dois clubes:");
        foreach (CurrentClubOffsetSummary x in report.OffsetSummaries.Take(60))
        {
            sb.AppendLine($"  {x.ReferenceKind,-19} {x.DataType,-6} rel={x.RelativeOffset,6} | FLA={x.FlamengoPlayers} COR={x.CorinthiansPlayers} total={x.DistinctPlayers} hits={x.TotalHits} | {x.Assessment}");
            if (x.FlamengoPlayers > 0) sb.AppendLine($"    Flamengo: {x.FlamengoNames}");
            if (x.CorinthiansPlayers > 0) sb.AppendLine($"    Corinthians: {x.CorinthiansNames}");
        }

        sb.AppendLine();
        sb.AppendLine("Interpretação automática:");
        CurrentClubOffsetSummary? best = report.OffsetSummaries.FirstOrDefault();
        if (best is null)
            sb.AppendLine("  INCONCLUSIVO: não apareceu um offset repetido fora da identidade e do campo conhecido −17.");
        else if (best.Assessment == "CURRENT_CLUB_CANDIDATE_STRONG")
            sb.AppendLine($"  EVIDÊNCIA_FORTE: {best.ReferenceKind}/{best.DataType} no offset {best.RelativeOffset:+0;-0;0} cobre {best.FlamengoPlayers} jogadores do Flamengo e {best.CorinthiansPlayers} do Corinthians.");
        else
            sb.AppendLine($"  MELHOR_CANDIDATO: offset {best.RelativeOffset:+0;-0;0}, cobertura Flamengo={best.FlamengoPlayers}, Corinthians={best.CorinthiansPlayers}; ainda requer nova validação.");

        sb.AppendLine();
        sb.AppendLine("O offset −17 é registrado nos hits, mas excluído dos resumos por já ter sido rejeitado como clube atual.");
        sb.AppendLine("Arquivos gerados: current-contract-reference-report.txt, current-contract-occurrences.csv, current-club-reference-hits.csv, current-club-offset-summaries.csv, current-club-contexts.txt e players-without-current-club-pattern.txt.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    private static string FormatOccurrencesCsv(CurrentContractReferenceReport report)
    {
        var sb = new StringBuilder("display_name,person_database_id,internal_person_id,expected_club_database_id,expected_club_save_index,reference_kind,reference_offset,is_identity_occurrence,context_hex\r\n");
        foreach (CurrentContractOccurrence x in report.Occurrences)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.PersonDatabaseId, x.InternalPersonId,
                x.ExpectedClubDatabaseId, x.ExpectedClubSaveIndex, x.ReferenceKind,
                $"0x{x.ReferenceOffset:X8}", x.IsIdentityOccurrence, x.ContextHex));
        return sb.ToString();
    }

    private static string FormatHitsCsv(CurrentContractReferenceReport report)
    {
        var sb = new StringBuilder("display_name,person_database_id,internal_person_id,expected_club_database_id,expected_club_name,expected_club_save_index,reference_kind,reference_offset,data_type,club_value_offset,relative_offset,is_identity_occurrence,is_known_minus17,signature_hex\r\n");
        foreach (CurrentClubReferenceHit x in report.ClubHits)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.PersonDatabaseId, x.InternalPersonId,
                x.ExpectedClubDatabaseId, Csv(x.ExpectedClubName), x.ExpectedClubSaveIndex,
                x.ReferenceKind, $"0x{x.ReferenceOffset:X8}", x.DataType,
                $"0x{x.ClubValueOffset:X8}", x.RelativeOffset,
                x.IsIdentityOccurrence, x.IsKnownMinus17, x.SignatureHex));
        return sb.ToString();
    }

    private static string FormatSummariesCsv(CurrentContractReferenceReport report)
    {
        var sb = new StringBuilder("reference_kind,data_type,relative_offset,flamengo_players,corinthians_players,distinct_players,total_hits,flamengo_names,corinthians_names,assessment\r\n");
        foreach (CurrentClubOffsetSummary x in report.OffsetSummaries)
            sb.AppendLine(string.Join(',', x.ReferenceKind, x.DataType, x.RelativeOffset,
                x.FlamengoPlayers, x.CorinthiansPlayers, x.DistinctPlayers, x.TotalHits,
                Csv(x.FlamengoNames), Csv(x.CorinthiansNames), x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(CurrentContractReferenceReport report)
    {
        var sb = new StringBuilder();
        foreach (CurrentClubOffsetSummary summary in report.OffsetSummaries.Take(25))
        {
            sb.AppendLine($"[{summary.Assessment}] {summary.ReferenceKind}/{summary.DataType} rel={summary.RelativeOffset:+0;-0;0} FLA={summary.FlamengoPlayers} COR={summary.CorinthiansPlayers}");
            foreach (CurrentClubReferenceHit hit in report.ClubHits
                         .Where(x => !x.IsIdentityOccurrence && !x.IsKnownMinus17 &&
                                     x.ReferenceKind == summary.ReferenceKind &&
                                     x.DataType == summary.DataType &&
                                     x.RelativeOffset == summary.RelativeOffset)
                         .Take(30))
            {
                sb.AppendLine($"  {hit.ExpectedClubName,-24} {hit.DisplayName,-24} pessoa=0x{hit.ReferenceOffset:X8} clube=0x{hit.ClubValueOffset:X8} sig={hit.SignatureHex}");
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
