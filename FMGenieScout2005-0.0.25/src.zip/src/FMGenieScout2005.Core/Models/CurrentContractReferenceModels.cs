namespace FMGenieScout2005.Core.Models;

public sealed record CurrentContractSample(
    string DisplayName,
    uint PersonDatabaseId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName);

public sealed record CurrentContractOccurrence(
    string DisplayName,
    uint PersonDatabaseId,
    uint InternalPersonId,
    uint ExpectedClubDatabaseId,
    uint ExpectedClubSaveIndex,
    string ReferenceKind,
    long ReferenceOffset,
    bool IsIdentityOccurrence,
    string ContextHex);

public sealed record CurrentClubReferenceHit(
    string DisplayName,
    uint PersonDatabaseId,
    uint InternalPersonId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName,
    uint ExpectedClubSaveIndex,
    string ReferenceKind,
    long ReferenceOffset,
    string DataType,
    long ClubValueOffset,
    int RelativeOffset,
    bool IsIdentityOccurrence,
    bool IsKnownMinus17,
    string SignatureHex);

public sealed record CurrentClubOffsetSummary(
    string ReferenceKind,
    string DataType,
    int RelativeOffset,
    int FlamengoPlayers,
    int CorinthiansPlayers,
    int DistinctPlayers,
    int TotalHits,
    string FlamengoNames,
    string CorinthiansNames,
    string Assessment);

public sealed record CurrentContractReferenceReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    uint FlamengoSaveIndex,
    uint CorinthiansSaveIndex,
    IReadOnlyList<CurrentContractOccurrence> Occurrences,
    IReadOnlyList<CurrentClubReferenceHit> ClubHits,
    IReadOnlyList<CurrentClubOffsetSummary> OffsetSummaries,
    IReadOnlyList<string> MissingPeople,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
