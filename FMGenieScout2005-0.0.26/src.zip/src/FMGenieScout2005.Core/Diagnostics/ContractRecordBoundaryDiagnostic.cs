using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Agrupa ocorrências de referências de pessoas por assinatura estrutural e estima
/// possíveis limites de registros. Não assume que exista um único layout universal.
/// Somente leitura; nenhum byte do save é modificado.
/// </summary>
public sealed class ContractRecordBoundaryDiagnostic
{
    private const uint FlamengoDatabaseId = 322;
    private const uint CorinthiansDatabaseId = 319;
    private const int ContextBefore = 128;
    private const int ContextAfter = 256;
    private const int BoundarySearchRadius = 256;
    private const int MinimumZeroRun = 8;

    private static readonly ContractBoundarySample[] Samples =
    [
        new("Andrezinho", 302728, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("André Bahia", 311169, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Bruno Santos", 8832815, FlamengoDatabaseId, "CR Flamengo", "SPECIAL_EMP"),
        new("Dimba", 303048, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Douglas Silva", 3300410, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Fabiano Eller", 3300219, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Júlio César Moraes", 8825041, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Júnior Baiano", 6900111, FlamengoDatabaseId, "CR Flamengo", "NORMAL"),
        new("Reginaldo Araújo", 3300780, FlamengoDatabaseId, "CR Flamengo", "SPECIAL_LST"),

        new("Édson Araújo", 308345, CorinthiansDatabaseId, "SC Corinthians Paulista", "NORMAL"),
        new("Fábio Baiano", 3300471, CorinthiansDatabaseId, "SC Corinthians Paulista", "SPECIAL_PRT"),
        new("Fábio Costa", 6900151, CorinthiansDatabaseId, "SC Corinthians Paulista", "NORMAL"),
        new("Luciano Ratinho", 6900008, CorinthiansDatabaseId, "SC Corinthians Paulista", "SPECIAL_LST"),
        new("Marcelo Magalhães", 302580, CorinthiansDatabaseId, "SC Corinthians Paulista", "SPECIAL_LST"),
        new("Bruno Octávio", 8832887, CorinthiansDatabaseId, "SC Corinthians Paulista", "NORMAL"),
        new("Alessandro", 3902245, CorinthiansDatabaseId, "SC Corinthians Paulista", "SPECIAL_LST"),
        new("Rosinei", 316596, CorinthiansDatabaseId, "SC Corinthians Paulista", "NORMAL"),
        new("Dinélson", 320774, CorinthiansDatabaseId, "SC Corinthians Paulista", "NORMAL")
    ];

    private readonly Fm2005PersonIdentityParser _personParser = new();
    private readonly Fm2005ClubParser _clubParser = new();

    public async Task<ContractRecordBoundaryReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Resolvendo pessoas e clubes de controle...");
        Fm2005PersonIdentityParseResult people = _personParser.Parse(data, source, sha, progress, cancellationToken);
        Fm2005ClubParseResult clubs = _clubParser.Parse(data, cancellationToken);
        Club flamengo = clubs.FindByDatabaseId(FlamengoDatabaseId)
            ?? throw new InvalidDataException("O Flamengo (ClubDatabaseId 322) não foi localizado.");
        Club corinthians = clubs.FindByDatabaseId(CorinthiansDatabaseId)
            ?? throw new InvalidDataException("O Corinthians (ClubDatabaseId 319) não foi localizado.");

        var resolved = new List<(ContractBoundarySample Sample, PersonIdentity Person)>();
        var missing = new List<string>();
        foreach (ContractBoundarySample sample in Samples)
        {
            PersonIdentity? person = people.FindByDatabaseId(sample.PersonDatabaseId);
            if (person is null)
                missing.Add($"{sample.DisplayName};{sample.PersonDatabaseId};IDENTIDADE_NAO_ENCONTRADA");
            else
                resolved.Add((sample, person));
        }

        progress?.Report("Localizando todas as referências conhecidas...");
        uint[] knownValues = resolved
            .SelectMany(x => new[] { x.Person.DatabaseId, x.Person.SequenceIndex })
            .Distinct()
            .ToArray();
        int[] allKnownOffsets = knownValues
            .SelectMany(value => FindUInt32(data, value, cancellationToken))
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        var occurrences = new List<ContractReferenceOccurrence>();
        foreach ((ContractBoundarySample sample, PersonIdentity person) in resolved)
        {
            cancellationToken.ThrowIfCancellationRequested();
            long identityOffset = person.NameOffset + (long)person.NameLength * 2L + 12L;
            AddOccurrences(data, sample, person, "PERSON_DATABASE_ID", person.DatabaseId,
                identityOffset, allKnownOffsets, occurrences, cancellationToken);
            AddOccurrences(data, sample, person, "INTERNAL_PERSON_ID", person.SequenceIndex,
                identityOffset, allKnownOffsets, occurrences, cancellationToken);
        }

        progress?.Report("Agrupando assinaturas estruturais...");
        ContractSignatureCluster[] clusters = occurrences
            .Where(x => !x.IsIdentityOccurrence)
            .GroupBy(x => new { x.ReferenceKind, x.StructuralSignature, x.SignatureHash })
            .Select(g => BuildCluster(g.Key.ReferenceKind, g.Key.StructuralSignature, g.Key.SignatureHash, g))
            .OrderByDescending(x => Math.Min(x.FlamengoPlayers, x.CorinthiansPlayers))
            .ThenByDescending(x => x.DistinctPlayers)
            .ThenByDescending(x => x.OccurrenceCount)
            .ThenBy(x => x.SignatureHash, StringComparer.Ordinal)
            .ToArray();

        progress?.Report("Estimando limites compartilhados...");
        ContractBoundaryCandidate[] boundaries = BuildBoundaryCandidates(occurrences);

        var report = new ContractRecordBoundaryReport(
            source, data.LongLength, sha, flamengo.SaveIndex, corinthians.SaveIndex,
            occurrences.OrderBy(x => x.DisplayName).ThenBy(x => x.ReferenceKind).ThenBy(x => x.ReferenceOffset).ToArray(),
            clusters, boundaries, missing, output, DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "contract-record-boundary-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "contract-reference-occurrences.csv"), FormatOccurrencesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "contract-signature-clusters.csv"), FormatClustersCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "contract-boundary-candidates.csv"), FormatBoundariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "contract-record-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllLinesAsync(Path.Combine(output, "people-not-resolved.txt"), report.MissingPeople, new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Diagnóstico de limites e assinaturas concluído.");
        return report;
    }

    private static void AddOccurrences(
        byte[] data,
        ContractBoundarySample sample,
        PersonIdentity person,
        string referenceKind,
        uint referenceValue,
        long identityOffset,
        int[] allKnownOffsets,
        List<ContractReferenceOccurrence> output,
        CancellationToken cancellationToken)
    {
        foreach (int offset in FindUInt32(data, referenceValue, cancellationToken))
        {
            bool identity = Math.Abs((long)offset - identityOffset) <= 64L;
            int previousZero = FindPreviousZeroRunDistance(data, offset);
            int nextZero = FindNextZeroRunDistance(data, offset + 4);
            int previousReference = FindPreviousReferenceDistance(allKnownOffsets, offset);
            int nextReference = FindNextReferenceDistance(allKnownOffsets, offset);
            string signature = BuildStructuralSignature(data, offset);
            string hash = Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes(signature))).Substring(0, 16);
            output.Add(new ContractReferenceOccurrence(
                sample.DisplayName, sample.PersonDatabaseId, person.SequenceIndex,
                sample.ExpectedClubDatabaseId, sample.ExpectedClubName, sample.SampleGroup,
                referenceKind, referenceValue, offset, identity,
                previousZero, nextZero, previousReference, nextReference,
                signature, hash, HexContext(data, offset, ContextBefore, ContextAfter)));
        }
    }

    private static ContractSignatureCluster BuildCluster(
        string referenceKind,
        string signature,
        string hash,
        IEnumerable<ContractReferenceOccurrence> source)
    {
        ContractReferenceOccurrence[] rows = source.ToArray();
        string[] names = rows.Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
        int fla = rows.Where(x => x.ExpectedClubDatabaseId == FlamengoDatabaseId).Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        int cor = rows.Where(x => x.ExpectedClubDatabaseId == CorinthiansDatabaseId).Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        int normal = rows.Where(x => x.SampleGroup == "NORMAL").Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        int special = rows.Where(x => x.SampleGroup != "NORMAL").Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        string assessment = fla >= 4 && cor >= 4 ? "SHARED_LAYOUT_STRONG"
            : fla >= 2 && cor >= 2 ? "SHARED_LAYOUT_MEDIUM"
            : names.Length >= 4 ? "SAME_CLUB_OR_VARIANT_CLUSTER"
            : names.Length >= 2 ? "SMALL_VARIANT_CLUSTER"
            : "ISOLATED_LAYOUT";
        return new ContractSignatureCluster(
            referenceKind, signature, hash, rows.Length, names.Length, fla, cor, normal, special,
            MinNonNegative(rows.Select(x => x.PreviousZeroRunDistance)), MaxNonNegative(rows.Select(x => x.PreviousZeroRunDistance)),
            MinNonNegative(rows.Select(x => x.NextZeroRunDistance)), MaxNonNegative(rows.Select(x => x.NextZeroRunDistance)),
            string.Join(" | ", names), assessment);
    }

    private static ContractBoundaryCandidate[] BuildBoundaryCandidates(IEnumerable<ContractReferenceOccurrence> source)
    {
        var entries = new List<(ContractReferenceOccurrence Row, string Kind, int Relative)>();
        foreach (ContractReferenceOccurrence row in source.Where(x => !x.IsIdentityOccurrence))
        {
            if (row.PreviousZeroRunDistance >= 0) entries.Add((row, "ZERO_RUN_BEFORE", -row.PreviousZeroRunDistance));
            if (row.NextZeroRunDistance >= 0) entries.Add((row, "ZERO_RUN_AFTER", row.NextZeroRunDistance));
            if (row.PreviousReferenceDistance >= 0) entries.Add((row, "KNOWN_REFERENCE_BEFORE", -row.PreviousReferenceDistance));
            if (row.NextReferenceDistance >= 0) entries.Add((row, "KNOWN_REFERENCE_AFTER", row.NextReferenceDistance));
        }

        return entries
            .GroupBy(x => new { x.Row.ReferenceKind, x.Kind, x.Relative })
            .Select(g =>
            {
                string[] names = g.Select(x => x.Row.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
                int fla = g.Where(x => x.Row.ExpectedClubDatabaseId == FlamengoDatabaseId).Select(x => x.Row.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
                int cor = g.Where(x => x.Row.ExpectedClubDatabaseId == CorinthiansDatabaseId).Select(x => x.Row.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
                string assessment = fla >= 4 && cor >= 4 ? "BOUNDARY_CANDIDATE_STRONG"
                    : fla >= 2 && cor >= 2 ? "BOUNDARY_CANDIDATE_MEDIUM"
                    : names.Length >= 4 ? "BOUNDARY_CANDIDATE_WEAK"
                    : "ISOLATED_BOUNDARY";
                return new ContractBoundaryCandidate(g.Key.ReferenceKind, g.Key.Relative, g.Key.Kind,
                    g.Count(), names.Length, fla, cor, string.Join(" | ", names), assessment);
            })
            .OrderByDescending(x => Math.Min(x.FlamengoPlayers, x.CorinthiansPlayers))
            .ThenByDescending(x => x.DistinctPlayers)
            .ThenByDescending(x => x.OccurrenceCount)
            .ThenBy(x => Math.Abs(x.RelativeOffset))
            .ToArray();
    }

    private static string BuildStructuralSignature(byte[] data, int referenceOffset)
    {
        const int before = 48;
        const int after = 96;
        var sb = new StringBuilder((before + after) / 4 * 3);
        for (int relative = -before; relative <= after - 4; relative += 4)
        {
            int offset = referenceOffset + relative;
            if (offset < 0 || offset + 4 > data.Length)
            {
                sb.Append("X|");
                continue;
            }

            if (relative == 0)
            {
                sb.Append("REF|");
                continue;
            }

            uint value = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));
            string category = value switch
            {
                0 => "Z",
                uint.MaxValue => "FF",
                <= 255 => "B",
                <= 65_535 => "S",
                <= 10_000_000 => "I",
                _ => "L"
            };
            sb.Append(category).Append('|');
        }
        return sb.ToString();
    }

    private static int FindPreviousZeroRunDistance(byte[] data, int referenceOffset)
    {
        int start = Math.Max(0, referenceOffset - BoundarySearchRadius);
        for (int end = referenceOffset - 1; end >= start + MinimumZeroRun - 1; end--)
        {
            int run = 0;
            for (int i = end; i >= start && data[i] == 0; i--) run++;
            if (run >= MinimumZeroRun) return referenceOffset - (end - run + 1);
            if (run > 0) end -= run - 1;
        }
        return -1;
    }

    private static int FindNextZeroRunDistance(byte[] data, int referenceEnd)
    {
        int end = Math.Min(data.Length, referenceEnd + BoundarySearchRadius);
        for (int start = referenceEnd; start <= end - MinimumZeroRun; start++)
        {
            int run = 0;
            for (int i = start; i < end && data[i] == 0; i++) run++;
            if (run >= MinimumZeroRun) return start - referenceEnd;
            if (run > 0) start += run - 1;
        }
        return -1;
    }

    private static int FindPreviousReferenceDistance(int[] offsets, int current)
    {
        int index = Array.BinarySearch(offsets, current);
        if (index < 0) index = ~index;
        while (index > 0 && offsets[index - 1] == current) index--;
        return index > 0 ? current - offsets[index - 1] : -1;
    }

    private static int FindNextReferenceDistance(int[] offsets, int current)
    {
        int index = Array.BinarySearch(offsets, current);
        if (index < 0) index = ~index;
        while (index < offsets.Length && offsets[index] <= current) index++;
        return index < offsets.Length ? offsets[index] - current : -1;
    }

    private static List<int> FindUInt32(byte[] data, uint value, CancellationToken cancellationToken)
    {
        byte b0 = (byte)value;
        byte b1 = (byte)(value >> 8);
        byte b2 = (byte)(value >> 16);
        byte b3 = (byte)(value >> 24);
        var result = new List<int>();
        for (int i = 0; i <= data.Length - 4; i++)
        {
            if ((i & 0xFFFF) == 0) cancellationToken.ThrowIfCancellationRequested();
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3)
                result.Add(i);
        }
        return result;
    }

    private static int MinNonNegative(IEnumerable<int> values)
    {
        int[] usable = values.Where(x => x >= 0).ToArray();
        return usable.Length == 0 ? -1 : usable.Min();
    }

    private static int MaxNonNegative(IEnumerable<int> values)
    {
        int[] usable = values.Where(x => x >= 0).ToArray();
        return usable.Length == 0 ? -1 : usable.Max();
    }

    private static string HexContext(byte[] data, int center, int before, int after)
    {
        int start = Math.Max(0, center - before);
        int length = Math.Min(data.Length - start, before + 4 + after);
        return Convert.ToHexString(data.AsSpan(start, length));
    }

    public static string FormatReport(ContractRecordBoundaryReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — ContractRecordBoundaryDiagnostic 0.0.26");
        sb.AppendLine(new string('=', 100));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Flamengo SaveIndex: {report.FlamengoSaveIndex}");
        sb.AppendLine($"Corinthians SaveIndex: {report.CorinthiansSaveIndex}");
        sb.AppendLine($"Ocorrências de referências: {report.Occurrences.Count:N0}");
        sb.AppendLine($"Clusters de assinatura: {report.SignatureClusters.Count:N0}");
        sb.AppendLine($"Candidatos de limite: {report.BoundaryCandidates.Count:N0}");
        sb.AppendLine($"Pessoas não resolvidas: {report.MissingPeople.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Melhores clusters estruturais:");
        foreach (ContractSignatureCluster x in report.SignatureClusters.Take(50))
            sb.AppendLine($"  {x.Assessment,-28} {x.ReferenceKind,-20} hash={x.SignatureHash} players={x.DistinctPlayers,2} FLA={x.FlamengoPlayers,2} COR={x.CorinthiansPlayers,2} normal={x.NormalPlayers,2} special={x.SpecialStatusPlayers,2} hits={x.OccurrenceCount,3} | {x.PlayerNames}");
        sb.AppendLine();
        sb.AppendLine("Melhores candidatos de limite:");
        foreach (ContractBoundaryCandidate x in report.BoundaryCandidates.Take(50))
            sb.AppendLine($"  {x.Assessment,-28} {x.ReferenceKind,-20} {x.BoundaryKind,-24} rel={x.RelativeOffset,5} players={x.DistinctPlayers,2} FLA={x.FlamengoPlayers,2} COR={x.CorinthiansPlayers,2} hits={x.OccurrenceCount,3} | {x.PlayerNames}");
        sb.AppendLine();
        sb.AppendLine("Interpretação: clusters compartilhados pelos dois clubes são candidatos a layouts comuns; clusters concentrados em NORMAL ou SPECIAL podem representar variantes de contrato, empréstimo, listagem ou inscrição.");
        sb.AppendLine("Nenhum campo é tratado como clube atual nesta etapa.");
        sb.AppendLine();
        sb.AppendLine("Arquivos: contract-record-boundary-report.txt, contract-reference-occurrences.csv, contract-signature-clusters.csv, contract-boundary-candidates.csv, contract-record-contexts.txt e people-not-resolved.txt.");
        return sb.ToString();
    }

    private static string FormatOccurrencesCsv(ContractRecordBoundaryReport report)
    {
        var sb = new StringBuilder("display_name,person_database_id,internal_person_id,expected_club_database_id,expected_club_name,sample_group,reference_kind,reference_value,reference_offset,is_identity,previous_zero_run_distance,next_zero_run_distance,previous_reference_distance,next_reference_distance,signature_hash,structural_signature,context_hex\r\n");
        foreach (ContractReferenceOccurrence x in report.Occurrences)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.PersonDatabaseId, x.InternalPersonId, x.ExpectedClubDatabaseId, Csv(x.ExpectedClubName), x.SampleGroup, x.ReferenceKind, x.ReferenceValue, Hex(x.ReferenceOffset), x.IsIdentityOccurrence, x.PreviousZeroRunDistance, x.NextZeroRunDistance, x.PreviousReferenceDistance, x.NextReferenceDistance, x.SignatureHash, Csv(x.StructuralSignature), x.ContextHex));
        return sb.ToString();
    }

    private static string FormatClustersCsv(ContractRecordBoundaryReport report)
    {
        var sb = new StringBuilder("reference_kind,signature_hash,occurrence_count,distinct_players,flamengo_players,corinthians_players,normal_players,special_status_players,min_previous_zero_run_distance,max_previous_zero_run_distance,min_next_zero_run_distance,max_next_zero_run_distance,assessment,player_names,structural_signature\r\n");
        foreach (ContractSignatureCluster x in report.SignatureClusters)
            sb.AppendLine(string.Join(',', x.ReferenceKind, x.SignatureHash, x.OccurrenceCount, x.DistinctPlayers, x.FlamengoPlayers, x.CorinthiansPlayers, x.NormalPlayers, x.SpecialStatusPlayers, x.MinPreviousZeroRunDistance, x.MaxPreviousZeroRunDistance, x.MinNextZeroRunDistance, x.MaxNextZeroRunDistance, x.Assessment, Csv(x.PlayerNames), Csv(x.StructuralSignature)));
        return sb.ToString();
    }

    private static string FormatBoundariesCsv(ContractRecordBoundaryReport report)
    {
        var sb = new StringBuilder("reference_kind,boundary_kind,relative_offset,occurrence_count,distinct_players,flamengo_players,corinthians_players,assessment,player_names\r\n");
        foreach (ContractBoundaryCandidate x in report.BoundaryCandidates)
            sb.AppendLine(string.Join(',', x.ReferenceKind, x.BoundaryKind, x.RelativeOffset, x.OccurrenceCount, x.DistinctPlayers, x.FlamengoPlayers, x.CorinthiansPlayers, x.Assessment, Csv(x.PlayerNames)));
        return sb.ToString();
    }

    private static string FormatContexts(ContractRecordBoundaryReport report)
    {
        var sb = new StringBuilder();
        foreach (ContractReferenceOccurrence x in report.Occurrences.Where(x => !x.IsIdentityOccurrence).OrderBy(x => x.SignatureHash).ThenBy(x => x.DisplayName).ThenBy(x => x.ReferenceOffset))
        {
            sb.AppendLine($"[{x.SignatureHash}] {x.DisplayName} | {x.ReferenceKind}={x.ReferenceValue} | offset={Hex(x.ReferenceOffset)} | group={x.SampleGroup} | zeroBefore={x.PreviousZeroRunDistance} zeroAfter={x.NextZeroRunDistance} refBefore={x.PreviousReferenceDistance} refAfter={x.NextReferenceDistance}");
            sb.AppendLine($"Signature: {x.StructuralSignature}");
            sb.AppendLine(x.ContextHex);
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string value) => '"' + value.Replace("\"", "\"\"") + '"';
    private static string Hex(long value) => $"0x{value:X8}";
}
