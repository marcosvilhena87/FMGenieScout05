namespace FMGenieScout2005.Core.Models;

public sealed record KnownPlayerRecordSample(
    string ExpectedClub,
    uint ExpectedClubDatabaseId,
    string DisplayName,
    uint PersonDatabaseId);

public sealed record PlayerRecordCandidate(
    string ExpectedClub,
    uint ExpectedClubDatabaseId,
    uint ExpectedClubSaveIndex,
    string DisplayName,
    uint PersonDatabaseId,
    long PersonDatabaseIdOffset,
    long ClubFieldOffset,
    uint ClubSaveIndexValue,
    uint? ResolvedClubDatabaseId,
    string? ResolvedClubName,
    bool IsIdentityOccurrence,
    string Classification,
    string ContextHex);

public sealed record PlayerRecordClubSummary(
    string ExpectedClub,
    uint ExpectedClubDatabaseId,
    uint ExpectedClubSaveIndex,
    int KnownPlayers,
    int ResolvedPeople,
    int ConfirmedPlayers,
    int ConfirmedOccurrences,
    int WrongClubOccurrences,
    int InvalidClubIndexOccurrences,
    string Assessment);

public sealed record PlayerRecordStructureReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    int RelativeClubOffset,
    IReadOnlyList<PlayerRecordCandidate> Candidates,
    IReadOnlyList<PlayerRecordClubSummary> ClubSummaries,
    IReadOnlyList<string> MissingPeople,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
