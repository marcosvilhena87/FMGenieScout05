namespace FMGenieScout2005.Core.Models;

public sealed record KnownPlayerIdentity(string Name, uint DatabaseId);

public sealed record PlayerIdentityNameHit(
    string PlayerName,
    uint ExpectedDatabaseId,
    long NameOffset,
    int EncodedByteLength,
    int OccurrenceNumber);

public sealed record PlayerIdentityIdHit(
    string PlayerName,
    uint ExpectedDatabaseId,
    long NameOffset,
    long IdOffset,
    long RelativeToNameStart,
    long RelativeToNameEnd,
    int Width,
    string DataType,
    string ContextHex);

public sealed record PlayerIdentityOffsetSummary(
    string DataType,
    long RelativeToNameStart,
    int PlayerCount,
    int HitCount,
    double Coverage,
    string Players,
    string Assessment);

public sealed record PlayerIdentityFieldSample(
    string PlayerName,
    uint ExpectedDatabaseId,
    long NameOffset,
    int RelativeOffset,
    string DataType,
    ulong Value,
    bool EqualsExpectedId);

public sealed record PlayerIdentityFieldSummary(
    int RelativeOffset,
    string DataType,
    int PlayerCount,
    int DistinctValueCount,
    int ExpectedIdMatchCount,
    double ExpectedIdMatchRate,
    string Values,
    string Assessment);

public sealed record PlayerIdentityStructureReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<KnownPlayerIdentity> ExpectedPlayers,
    IReadOnlyList<PlayerIdentityNameHit> NameHits,
    IReadOnlyList<PlayerIdentityIdHit> IdHits,
    IReadOnlyList<PlayerIdentityOffsetSummary> IdOffsetSummaries,
    IReadOnlyList<PlayerIdentityFieldSample> FieldSamples,
    IReadOnlyList<PlayerIdentityFieldSummary> FieldSummaries,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
