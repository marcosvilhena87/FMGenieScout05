using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Models;

public sealed record KnownPersonValidation(
    string DisplayName,
    uint DatabaseId,
    IReadOnlyList<string> ExpectedIdentityNames);

public sealed record PersonIdentityValidation(
    string DisplayName,
    uint ExpectedDatabaseId,
    bool Found,
    string? ParsedIdentityName,
    uint? SequenceIndex,
    ushort? RecordType,
    long? RecordOffset,
    long? NameOffset,
    bool NameMatches,
    string Status);

public sealed record PersonIdentityParserReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<PersonIdentity> People,
    int RejectedCandidateCount,
    IReadOnlyList<PersonIdentityValidation> Validations,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
